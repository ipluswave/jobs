#This is my extremely hackish iris and pupil tracker/detector.
import time
import cv2
import pupil_detect
eyeCascadeClassifier = cv2.CascadeClassifier("haarcascade_eye.xml")

class Eye():

    def __init__(self,x, y, x2, y2):
        self.x = x
        self.y = y
        self.x2 = x2
        self.y2 = y2
        self.width = x2 - x
        self.height = y2 - y
        self.topcorner = (x, y)
        self.bottomcorner = (x2, y2)
		
def detectObjects(image, objectClassifier, divider=4):
    #increase divider for more speed, less accuracy
    grayImage = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    small_image = cv2.resize(grayImage, (grayImage.shape[1]/divider,grayImage.shape[0]/divider))
    objects = objectClassifier.detectMultiScale(small_image, 1.2, 2, 0, (20,20))
    return objects*divider

def draw(photo):
    image = photo.copy()
    imageToShow = image
    eyes = detectObjects(image, eyeCascadeClassifier)
    rightmost_eye = None
    if eyes is not None:
        for eye in eyes:
            (x,y) = eye[0], eye[1]
            (x2,y2) = (eye[0] + eye[2]), (eye[1] + eye[3])
            if (rightmost_eye is None) or (x < rightmost_eye.x):
                rightmost_eye = Eye(x, y, x2, y2)
    eye_image = None
    if rightmost_eye is not None:
        eye_image = image[rightmost_eye.y:rightmost_eye.y2, rightmost_eye.x:rightmost_eye.x2]
    binary_eye_image = None
    if eye_image is not None:
        eye_histogram = [0]*256
        eye_image = cv2.cvtColor(eye_image, cv2.COLOR_RGB2GRAY)
        for i in xrange(256):
            value_count = (eye_image == i).sum()
            eye_histogram[i] = value_count
        count = 0
        index = 255
        while count < (eye_image.size*3/4):
            count += eye_histogram[index]
            index -= 1
        quarter_threshold = index
        binary_eye_image = cv2.equalizeHist((eye_image < quarter_threshold) * eye_image)

    relative_iris_coordinates = None
    if binary_eye_image is not None:
        eye_circles = cv2.HoughCircles(binary_eye_image, cv2.cv.CV_HOUGH_GRADIENT, 3, 500, maxRadius = binary_eye_image.shape[0]/5)
        if eye_circles is not None:
            circle = eye_circles[0][0]
            relative_iris_coordinates = (circle[0], circle[1])
    absolute_iris_coordinates = None
    if relative_iris_coordinates is not None and rightmost_eye is not None:
        absolute_iris_coordinates = (int(relative_iris_coordinates[0]+rightmost_eye.x), int(relative_iris_coordinates[1]+rightmost_eye.y))
        cv2.circle(imageToShow, absolute_iris_coordinates, 5, (255,0,0), thickness=10)
    irisImage = None
    if absolute_iris_coordinates is not None:
        x = absolute_iris_coordinates[0]
        y = absolute_iris_coordinates[1]
        w = 60
        h = 60
        irisImage = photo[y-h:y+h,x-w:x+w]
        irisImageToShow = cv2.resize(irisImage, (irisImage.shape[1]*2, irisImage.shape[0]*2))
        imageToShow[0:irisImageToShow.shape[0], 00:00+irisImageToShow.shape[1]] = irisImageToShow
    iris_picture = None
    if irisImage is not None:
        iris_gray = cv2.cvtColor(irisImage, cv2.COLOR_RGB2GRAY)
        irisCirclesImage = irisImage.copy()
        iris_circles = cv2.HoughCircles(iris_gray, cv2.cv.CV_HOUGH_GRADIENT, 2, 100)
        if iris_circles is not None:
            circle=iris_circles[0][0]
            cv2.circle(irisCirclesImage, (circle[0], circle[1]), circle[2], (255,0,0), thickness=2)
        pupil_coords = pupil_detect.find_pupil(iris_gray)
        if pupil_coords is not None:
            cv2.circle(irisCirclesImage, pupil_coords[:2], pupil_coords[2], (0,255,0),4)
        if iris_circles is not None and pupil_coords is not None:
            ic = iris_circles[0][0]
            pc = pupil_coords
            if abs(ic[0]-pc[0])<ic[2] and abs(ic[1]-pc[1])<ic[2] and pc[2]<ic[2]:
                iris_picture = irisCirclesImage
        irisCirclesToShow = cv2.resize(irisCirclesImage, (irisCirclesImage.shape[1]*2,irisCirclesImage.shape[0]*2))
        imageToShow[0:irisCirclesToShow.shape[0], 200:200+irisCirclesToShow.shape[1]] = irisCirclesToShow
    cv2.imshow('Image', imageToShow)
    if cv2.waitKey(10) > 0:
        return True, iris_picture
    return False, iris_picture

def main():
    camera = cv2.VideoCapture(0)
    foundIrisCounter = 0
    while True:
        success, photo = camera.read()
        finished, iris_pic = pupil_detect.draw(photo)
        if iris_pic is not None:
            timecode = time.strftime("%Y-%m-%d_%H;%M;%S", time.gmtime())
            cv2.imwrite("iris_pic_"+str(foundIrisCounter)+"_"+timecode+".jpg", iris_pic)
            foundIrisCounter += 1
        if finished:
            break

if __name__ == '__main__':
    main()
