package vo.r;

import java.io.File;

public class R {

	private File r_directory;
	private File r_input;
	private File r_output;
	
	public File getR_directory() {
		return r_directory;
	}
	public void setR_directory(File r_directory) {
		this.r_directory = r_directory;
	}
	public File getR_input() {
		return r_input;
	}
	public void setR_input(File r_input) {
		this.r_input = r_input;
	}
	public File getR_output() {
		return r_output;
	}
	public void setR_output(File r_output) {
		this.r_output = r_output;
	}
	
	

}