﻿using System;
using System.Configuration;
using System.Globalization;
using System.Security.Policy;
using CommonApi.ServiceRequest;
using GatewayCommonApi;
using GatewayCommonApi.Model.Domain;
using GatewayCommonApi.Request.Domain;
using NUnit.Framework;

namespace OverviewApi
{
    [SetUpFixture]
    public class TestFixture
    {
        public static string GatewayUrl { get; private set; }
        public static string CustomerUrlBase { get; private set; }
        public static string VehicleHistoryBase { get; private set; }

        public static Guid GetOverviewToken(string name, string password)
        {
            var fromLoginQueryModel = new FromLoginQueryModel
            {
                Name = name,
                Password = password
            };

            // The AccountDomainRequest class (and all other request classes) is a helper class
            // that constructs an appropriate URL for the desired function, packages the request 
            // data, calls the appropriate HTTP function, then unwraps the result.
            var accountRequest = new AccountDomainRequest(GCAn.GetGatewayService(GatewayUrl), Guid.Empty);

            var result = accountRequest.GetUserFromLogin(fromLoginQueryModel);
            if (result == null)
                throw new ArgumentException("Could not find user account");

            return result.Identity;
        }

        [OneTimeSetUp]
        public void SetUp()
        {
            var host = ConfigurationManager.AppSettings["ServiceHost"];
            var port = ConfigurationManager.AppSettings["ServicePort"];
            var gatewayServicePath = ConfigurationManager.AppSettings["GatewayServicePath"];
            var customerServicePath = ConfigurationManager.AppSettings["CustomerServicePath"];

            GatewayUrl = string.Concat(host, ":", port, gatewayServicePath);
            CustomerUrlBase = string.Concat(host, ":", port, customerServicePath);

            VehicleHistoryBase = ConfigurationManager.AppSettings["VehicleHistoryReportServicePath"];
        }

        [OneTimeTearDown]
        public void TearDown()
        {
        }
    }
}