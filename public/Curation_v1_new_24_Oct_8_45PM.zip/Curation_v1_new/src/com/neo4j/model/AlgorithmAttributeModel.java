package com.neo4j.model;

import org.springframework.data.neo4j.annotation.GraphId;
import org.springframework.data.neo4j.annotation.Indexed;
import org.springframework.data.neo4j.annotation.NodeEntity;

@NodeEntity
public class AlgorithmAttributeModel {

	@GraphId
	private Long id;
	@Indexed(unique=true)
	private String attributeName;
	
	//@RelatedTo(type = "HAS_PARAMETERS", direction = Direction.INCOMING)
	private Long algorithmId;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getAttributeName() {
		return attributeName;
	}
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
	public Long getAlgorithmId() {
		return algorithmId;
	}
	public void setAlgorithmId(Long algorithmId) {
		this.algorithmId = algorithmId;
	}
}