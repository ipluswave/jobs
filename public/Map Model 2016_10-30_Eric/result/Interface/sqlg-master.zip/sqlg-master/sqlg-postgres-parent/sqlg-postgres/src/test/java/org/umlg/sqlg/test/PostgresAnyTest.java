package org.umlg.sqlg.test;

import org.umlg.sqlg.AnyTest;

/**
 * Date: 2014/07/16
 * Time: 12:11 PM
 */
public class PostgresAnyTest extends AnyTest {
}
