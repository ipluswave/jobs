<?php

namespace App\Http\Composers;

use Illuminate\Contracts\View\View;

class DashboardMenuComposer
{
    protected $menu;

    public function __construct()
    {
        $this->menu = [
            'Dashboard' => '/home'
        ];
    }

    public function compose(View $view)
    {
        $view->with('menu', $this->menu);
    }
}