<?php

namespace App\Http\Controllers\Auth;

use Request;

use App\User;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use JWTAuth;
use Tymon\JWTAuth\Token;
use Log;
use Cookie;
use Validator;

class AuthenticateController extends Controller
{
    public function authenticate(\Illuminate\Http\Request $request)
    {
        // grab credentials from the request
        $credentials = $request->only('email', 'password');

        try {
            // attempt to verify the credentials and create a token for the user
            if (! $token = JWTAuth::attempt($credentials)) {
                return response()->json(['error' => 'invalid_credentials'], 401);
            }
        } catch (JWTException $e) {
            // something went wrong whilst attempting to encode the token
            return response()->json(['error' => 'could_not_create_token'], 500);
        }

        // all good so return the token
        return response()->json(compact('token'));
    }

    public function getAuthenticatedUser()
    {
        if (! $user = JWTAuth::parseToken()->authenticate())
        {
            return response()->json(['user_not_found'], 404);
        }
        return response()->json(compact('user'));
    }

    public function logout()
    {
        Log::info(Request::cookie('jwt-token'));
        if(Request::cookie('jwt-token'))
        {
            $tok = new Token(Request::cookie('jwt-token'));
            JWTAuth::invalidate($tok);
        }
        else
        {
            JWTAuth::parseToken()->invalidate();
        }
    }

    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|confirmed|min:6',
        ]);
    }


    protected function postRegister(\Illuminate\Http\Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|confirmed|min:6',
        ]);

        if ($validator->fails()) {
            return redirect('auth/register')
                ->withErrors($validator)
                ->withInput();
        }
        $data = $request->all();
        User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
        ]);
        return redirect('auth/login');
    }
}
