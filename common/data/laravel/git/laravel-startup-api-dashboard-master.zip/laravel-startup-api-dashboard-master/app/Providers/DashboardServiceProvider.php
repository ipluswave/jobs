<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use View;

class DashboardServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        View::composer('layouts.dashboard', 'App\Http\Composers\DashboardMenuComposer');
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
