var view = new ol.View({
    center: [11321217.246802684, 351595.9981690072],
    zoom: 14
});

var map = new ol.Map({
    controls: ol.control.defaults().extend([
        new ol.control.FullScreen()
    ]),
    layers: [
        new ol.layer.Tile({
            source: new ol.source.OSM()
        })
    ],
    target: 'map',
    view: view
});

map.on('click', function(evt) {
    var lonlat = ol.proj.transform(evt.coordinate, 'EPSG:3857', 'EPSG:4326');
    var lon = lonlat[0];
    var lat = lonlat[1];
    console.log("Latitude : " + lat + " , Longitude : " + lon);
});