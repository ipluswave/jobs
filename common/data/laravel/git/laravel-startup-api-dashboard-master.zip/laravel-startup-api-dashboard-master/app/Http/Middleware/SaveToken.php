<?php

namespace App\Http\Middleware;

use Closure;
use Cookie;
use Log;

class SaveToken
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $response = $next($request);
        $cookie = Cookie::make('jwt-token', $response->getData()->token);
        return redirect('home')->withCookie($cookie);
    }
}
