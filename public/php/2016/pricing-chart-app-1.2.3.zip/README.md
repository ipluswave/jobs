# Price Chart
Organize your pricing plans in a customizable price chart

Are you selling a service with multiple pricing plans? Want potential clients to be able to clearly and efficiently see your pricing at a glance? Then you’ll want to add the Price Chart app to neatly display your different pricing plans to your potential customers. 

A series of design options allows you to customize your pricing tables. With multiple layouts you’ll be able to showcase your pricing how you like. You can also fully customize the pricing table color scheme to match the table’s design to the aesthetic of your website.  Add it to your website today and get your pricing organized.
