@extends('layouts.index')

@section('title')
    API Management
@stop

@section('head')

@stop


@section('content')
    @include('common.header')
    @include('common.menu')

    <div id="main-page" class="content-wrapper api_connect">
        <div class="container">
            <p>Your connection '<span id="connection_name">{{$deletedConnection->name}}</span>' to <span id=api_name">{{$deletedConnection->api->name}}</span> was succesfully removed.</p>
            <p>You will be redirected to the connections list in <span id="timeout_seconds">5</span> seconds, <a href="{{wkp_url('',['api-manager'])}}">or go now!</a></p>
        </div>
    </div>
    @include('common.footer')
@stop

@section('footer_scripts')
    <script type="text/javascript">
        $( document ).ready(function() {
            window.setTimeout(function(){

                // Move to a new location or you can do something else
                window.location.href = "{{wkp_url('',['api-manager'])}}";

            }, 5000);
        });

    </script>
@stop