package org.umlg.sqlg.structure;

/**
 * Created by pieter on 2014/09/24.
 */
@FunctionalInterface
public interface ElementPropertyRollback {
    void clearProperties();
}
