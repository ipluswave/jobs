 @extends('layouts.index')

@section('title')
    API Management
@stop

@section('head')
    <link href="{{wkp_url('',['css','select2.css'])}}" rel="stylesheet" />
    <link href="{{wkp_url('',['css','select2.bootstrap.css'])}}" rel="stylesheet" />
@stop

@section('sub_head')
    <link href="{{wkp_url('',['css','api.css'])}}" rel="stylesheet" />
@stop


@section('content')
    @include('common.header')
    @include('common.menu')
    
<div id="main-page" class="content-wrapper api_connect">
    <section class="content-header span6">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <div class="box width-auto display-inline-block">
                    <div class="form-group">
                      <h3 class="api_management_header">{{trans('api.titles.api_management')}}</h3>  >  <h3 class="display-inline-block api_new_api_connection_header ">{{trans('api.titles.new_api_connection')}}</h3>
                    </div>
                </div>
            </div>
        </div>
    </section>
    {!!   Form::open(array('url' => wkp_url('',['api-manager','created']),'role'=>'form','id'=>'api_man','method' => 'POST','class' => 'form')) !!}
        <section class="content-centered span6 content-header">
            <div class="row margin-bottom-30">
                <div class="col-md-12">
                    <h1 class="api_header_text">{{trans('api.contents.now_you_need_to_integrate_your_first_api')}}<small>{{trans('api.contents.integrate_your_first_api_text')}}</small></h1>
                </div>
            </div>
            <div class="row">
                <div class="form-group {{$errors->has('api_type') ? 'has-error' : ''}}">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-md-offset-3 col-sm-offset-3">
                            {!! Form::label('api_type',trans('commons.labels.choose_the_api_type')) !!}
                            @if($errors->has('api_type'))
                                <div class="error-feedback">
                                    {{$errors->first('api_type')}}
                                </div>
                            @endif
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-md-offset-3 col-sm-offset-3">
                            {!! Form::select('api_type', [ '' => trans('commons.labels.choose_the_api_type')] +  $categories->toArray() ,null, ['class' => 'form-control','onchange' =>'onGetApis(this)']) !!}
                        </div>
                    </div>
                </div>


                <div class="form-group {{$errors->has('api') ? 'has-error' : ''}}" id="api_group" style="display: none;">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-md-offset-3 col-sm-offset-3">
                            {!! Form::label('api', trans('commons.labels.provider')) !!}
                                @if($errors->has('api'))
                                    <div class="error-feedback">
                                        {{$errors->first('api')}}
                                    </div>
                                @endif
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-md-offset-3 col-sm-offset-3">
                            {!! Form::select('api', array('' => trans('commons.hints.api')) +  $apisSelect ,null , ['class' => 'form-control','onchange' =>"onGetKeys(this)"]) !!}
                        </div>
                    </div>
                </div>
                <div class="form-group {{$errors->has('api_uid') ? 'has-error' : ''}}" id="uid_group" style="display: none;">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-md-offset-3 col-sm-offset-3">
                           {!! Form::label('api_uid', trans('commons.labels.apiuid')) !!}
                           @if($errors->has('api_uid'))
                               <div class="error-feedback">
                                   {{$errors->first('api_uid')}}
                               </div>
                           @endif
                       </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-md-offset-3 col-sm-offset-3 col-xs-6">
                            {!! Form::text('api_uid','', ['class' => 'form-control']) !!}
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-6">
                            <a href="javascript:void(0)" class="fa fa-question-circle margin-top-10 help-color" data-toggle="tooltip" data-placement="right" title="" id="api_uid_title"></a>
                        </div>
                    </div>
                </div>
                    <div class="form-group {{$errors->has('api_key') ? 'has-error' : ''}}" id="secret_group" style="display: none;">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-md-offset-3 col-sm-offset-3 col-xs-6">
                                {!! Form::label('api_key', trans('commons.labels.apikey')) !!}
                                @if($errors->has('api_key'))
                                    <div class="error-feedback">
                                        {{$errors->first('api_key')}}
                                    </div>
                                @endif
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-md-offset-3 col-sm-offset-3 col-xs-6">
                                {!! Form::text('api_key','', ['class' => 'form-control']) !!}
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-6">
                                <a href="javascript:void(0)" class="fa fa-question-circle margin-top-10 help-color" data-toggle="tooltip" data-placement="right" title="" id="api_key_title"></a>
                            </div>
                        </div>
                    </div>

                    <div class="form-group {{$errors->has('api_url') ? 'has-error' : ''}}" id="url_group" style="display: none;">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-md-offset-3 col-sm-offset-3 col-xs-6">
                                {!! Form::label('api_url', trans('commons.labels.apiUrl')) !!}
                                @if($errors->has('api_url'))
                                    <div class="error-feedback">
                                        {{$errors->first('api_url')}}
                                    </div>
                                @endif
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-md-offset-3 col-sm-offset-3 col-xs-6">
                                {!! Form::text('api_url','', ['class' => 'form-control']) !!}
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-6">
                                <a href="javascript:void(0)" class="fa fa-question-circle margin-top-10 help-color" data-toggle="tooltip" data-placement="right" title="" id="api_url_title"></a>
                            </div>
                        </div>
                    </div>
                    <div class="row margin-top-20 margin-bottom-30" id="submit_row" style="display: none">
                        <div class="col-md-8 col-sm-8 col-md-offset-3 col-sm-offset-3">
                            <div class="row">
                                <div class="col-md-8 col-sm-8 col-xs-8" style="text-align: center">
                                    {!! Form::submit(trans('commons.buttons.continue'), ['class' => 'submit-green btn']) !!}
                                </div>
                            </div>

                        </div>
                    </div>
            </div>
        </section>

    {!!  Form::close() !!}
</div>
@include('common.footer')
@stop

@section('footer_scripts')
   <script type="application/javascript" src="{{wkp_url('',['js','select2.full.js'])}}"></script>
   <script type="application/javascript" src="{{wkp_url('',['js','bootstrap-tooltip.js'])}}"></script>
   <script type="application/javascript">
       $(document).ready(function () {
          // $('[data-toggle="tooltip"]').tooltip()
       });

     function formatEle(data){
       var markup =  "";
       if(data.icon_url) {
         markup += "<div style='min-height:60px'><img style='float:left; margin-right:10px' src='{{wkp_url('')}}/" + data.icon_url + "' /><div>";
       }
       markup += "<b>"+data.name+"</b><br/>";
       if(data.description){
         markup += "<small>"+data.description+"</small>";
       }
       markup += "</div>";
       return markup;

     }

     function formatEleSelect (data) {
       console.log('formatting data selected: ' + data.name);
       return data.name;
     }



     function checkCatipoAPI(api_id) {
       var requestURL = '{{wkp_url('',['api-manager','fastping'])}}/'+api_id;
       $.getJSON(requestURL, function () {
         console.log("success asking to Catipo");
       }).done(function(data) {
         console.log("success asking to Catipo: done");
         if (data && data.status == 'ok') {
           console.log("done:  status OK");
           checkAPIWebPing(data.url,api_id);
         } else {
           console.log("done:  status fail");
           alert('The Catipo response wasnt succesful');
         }
       });
     }
     function checkAPIWebPing(url,api_id){
       console.log("checkAPIWebPing " + url);

       var jqxhr = $.getJSON(url , function () {
         console.log("success ping to " + url);
       }).done( function(data) {
         console.log("done method on " + url);
         if (data) {
           console.log('data exists');
           if( data.response){
             if(data.response.status == 'ok' || data.response.status == 'OK' || data.response.status == '1'){
               console.log('SUCCESS');
               apiConnectSuccess(api_id);
               return null;
             }
           }else{
             if(data.status == 'ok' || data.status == 'OK' || data.status == '1'){
               console.log('SUCCESS');
               apiConnectSuccess(api_id);
               return null;
             }
           }
         }
       });

     }
     function apiConnectSuccess(api_id){
       alert('success on ' + api_id + " ;)");
     }

     function requestBlock(id,shallBeBlocked){
       var requestURL = '';
       if(shallBeBlocked){
         requestURL = "{{wkp_url('',['api-manager','block'])}}/" + id;
       }else if(shallBeBlocked == false){
         requestURL = "{{wkp_url('',['api-manager','unblock'])}}/" + id;
       }
       $.getJSON(requestURL, function () {
       }).done(function(data) {
         if (data.status == 'ok') {
           if(data.connectionStatus == 'unblocked'){
             $('#connection_row_' + data.id).attr('title','').removeClass('apiblocked');
             $('#connection_row_' + data.id +' .fa-lock ').removeClass('fa-lock').addClass('fa-unlock');
             $('#connection_row_' + data.id +' .locker').attr('onclick',"requestBlock('"+data.id+"', true )").attr('title',"{{trans('commons.actions.lock')}}");
           }else if(data.connectionStatus == 'blocked'){
             $('#connection_row_' + data.id).attr('title','{{trans('commons.titles.connectionRemainsBlocked')}}').addClass('apiblocked');
             $('#connection_row_' + data.id +' .fa-unlock').removeClass('fa-unlock').addClass('fa-lock');
             $('#connection_row_' + data.id +' .locker').attr('onclick',"requestBlock('"+data.id+"', false )").attr('title',"{{trans('commons.actions.unlock')}}");
           }
         } else {
           console.log("done:  status fail:");
           console.log("Server Error: " + data.error);

         }
       });
     }
     function empty(){

         $("#api_uid").val('');
         $("#api_key").val('');
         $("#api_url").val('');
         $("#api_group").hide();
         $("#uid_group").hide();
         $("#secret_group").hide();
         $("#url_group").hide();
         $("#submit_row").hide();
     }
     function onGetApis(obj){
         var apiTypeID = $(obj).val();
         if(apiTypeID){
             $("#api").html('');
             empty();
             $.ajax ({
                 url: '{{wkp_url('',['api-manager','getApiList'])}}',
                 type: 'POST',
                 data: {api_type : apiTypeID,_token: $( "input[name='_token']").val()},
                 cache: false,
                 dataType : "json",
                 success: function (data) {
                     if(data.result == "success"){
                        $("#api").html(data.list);
                        //$("#api").select2();
                         $("#api_group").show();
                     }else{
                         $("#api").html('');
                         empty();
                     }
                 }
             });
         }
     }
     function onGetKeys(obj){
        var apiID = $(obj).val();
        if(apiID){
            $.ajax ({
                url: '{{wkp_url('',['api-manager','getApiLabel'])}}',
                type: 'POST',
                data: {apiID : apiID,_token: $( "input[name='_token']").val()},
                cache: false,
                dataType : "json",
                success: function (data) {
                    if(data.result == "success"){
                        if(data.list.length >0){
                            $("#api_uid").val('');
                            $("#api_key").val('');
                            $("#api_url").val('');
                            $('[data-toggle="tooltip"]').tooltip('destroy');
                            if(data.list[0].uid_key != null && data.list[0].uid_key != ''){
                                if(data.list[0].uid_key_description != null && data.list[0].uid_key_description != ''){
                                    $("#api_uid_title").prop('title', data.list[0].uid_key_description);
                                    $("#api_uid_title").show();
                                }else{
                                    $("#api_uid_title").hide();
                                }
                                $('#uid_group label').html(''+data.list[0].uid_key);
                                $('#uid_group').show();
                            }
                            if(data.list[0].secret_key != null && data.list[0].secret_key != ''){
                                if(data.list[0].secret_key_description != null && data.list[0].secret_key_description != ''){
                                    $("#api_key_title").prop('title', data.list[0].secret_key_description);
                                    $("#api_key_title").show();
                                }else{
                                    $("#api_key_title").hide();
                                }
                                $('#secret_group label').html(data.list[0].secret_key);
                                $('#secret_group').show();
                            }else{
                                $('#secret_group').hide();
                            }
                            if(data.list[0].url_key != null && data.list[0].url_key != ''){
                                if(data.list[0].url_key_description != null && data.list[0].url_key_description != ''){
                                    $("#api_url_title").prop('title', data.list[0].url_key_description);
                                    $("#api_url_title").show();
                                }else{
                                    $("#api_url_title").hide();
                                }
                                $('#url_group label').html(data.list[0].url_key);
                                $('#url_group').show();
                            }else{
                                $('#url_group').hide();
                            }
                            $('[data-toggle="tooltip"]').tooltip();
                            $("#submit_row").show();
                        }else{
                            empty();
                        }
                    }
                }
            });
        }
     }


     @if (count($errors) > 0)
         @foreach ($errors->all() as $error)
           $.notify({message: '{{$error}}'},{type: 'danger',animate: {enter: 'animated fadeInRight', exit: 'animated fadeOutRight'}});
     @endforeach
 @endif

 @if($status['created'])
     $.notify({message: '{{$status['created']}}'},{type: 'success',animate: {enter: 'animated fadeInRight', exit: 'animated fadeOutRight'}});
     @endif





   </script>
 @stop