* change pom to non snapshot version
* mvn clean deploy -P release
* log in to https://oss.sonatype.org
* close and release the artifacts