var elixir = require('laravel-elixir');

/*
 |--------------------------------------------------------------------------
 | Elixir Asset Management
 |--------------------------------------------------------------------------
 |
 | Elixir provides a clean, fluent API for defining some basic Gulp tasks
 | for your Laravel application. By default, we are compiling the Sass
 | file for our application, as well as publishing vendor resources.
 |
 */

elixir(function(mix) {
    mix.sass('app.scss');
    mix.styles([
        'bootstrap.min.css',
        'metisMenu.min.css',
        'timeline.css',
        'sb-admin-2.css',
        'morris.css',
        'font-awesome.min.css',
        'ol.css',
        'openlayers-style.css'
    ]);
    mix.scripts([
        'jquery.min.js',
        'bootstrap.min.js',
        'metisMenu.min.js',
        'raphael-min.js',
        'morris.min.js',
        'sb-admin-2.js'
    ]);
    mix.scripts([
        'roles-create.js'
    ], 'public/js/roles-create.js');
    mix.scripts([
        'morris-data.js'
    ], 'public/js/home-script.js');
    mix.scripts([
        'ol.js',
        'openlayers-conf.js'
    ], 'public/js/map-scripts.js')
});
