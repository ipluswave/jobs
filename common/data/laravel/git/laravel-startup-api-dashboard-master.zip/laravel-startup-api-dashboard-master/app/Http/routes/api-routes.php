<?php

$api->version('v1', function ($api)
{
    $api->post('login', 'App\Http\Controllers\Auth\AuthenticateController@authenticate');

    $api->get('get/user', ['middleware' => 'jwt.auth'], 'App\Http\Controllers\Auth\AuthenticateController@getAuthenticatedUser');

    $api->get('logout', ['middleware' => 'jwt.auth'], 'App\Http\Controllers\Auth\AuthenticateController@logout');


    $api->group(['middleware' => 'jwt.auth'], function () use($api)
    {
        foreach (new DirectoryIterator(__DIR__.DS.'api-protected') as $file)
        {
            if (!$file->isDot() && !$file->isDir() && $file->getFilename() != '.gitignore')
            {
                require_once __DIR__.DS.'api-protected'.DS.$file->getFilename();
            }
        }
    });
});