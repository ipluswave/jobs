package org.umlg.sqlg.test;

import org.umlg.sqlg.AllTest;

/**
 * @author Lukas Krejci
 * @since 1.3.0
 */
public class H2AllTest extends AllTest {
}
