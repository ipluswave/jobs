<?php

namespace App\Http\Middleware;

use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Exceptions\TokenExpiredException;
use Tymon\JWTAuth\Middleware\BaseMiddleware;
use Request;
use Cookie;

class RedirectIfValidToken extends BaseMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, \Closure $next)
    {
        if (! ($token = $this->auth->setRequest($request)->getToken()))
        {
            if(! ($token = Request::cookie('jwt-token')))
            {
                return $next($request);
            }
        }

        try {
            $user = $this->auth->authenticate($token);
        } catch (TokenExpiredException $e) {
            return $next($request);
        } catch (JWTException $e) {
            return $next($request);
        }

        if (! $user) {
            return $next($request);
        }

        $this->events->fire('tymon.jwt.valid', $user);

        return redirect('home');
    }
}
