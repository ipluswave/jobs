package vo.ymal;

public class Mapping {

	private String localParameter;
	private String redshifttableName;
	private String type;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getRedshifttableName() {
		return redshifttableName;
	}
	public void setRedshifttableName(String redshifttableName) {
		this.redshifttableName = redshifttableName;
	}
	public String getLocalParameter() {
		return localParameter;
	}
	public void setLocalParameter(String localParameter) {
		this.localParameter = localParameter;
	}
}
