#!/bin/sh

#mvn -q test
mvn -e test
