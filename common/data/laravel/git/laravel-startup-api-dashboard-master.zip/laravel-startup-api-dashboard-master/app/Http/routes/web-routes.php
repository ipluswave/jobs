<?php

Route::get('/', function()
{
    return redirect('auth/login');
});

Route::group(['middleware' => 'jwt.auth'], function ()
{
    Route::get('home', 'Client\Dashboard\DashboardController@index');
});