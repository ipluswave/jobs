@extends('layouts.index')

@section('title')
    {{trans('commons.titles.myConnections')}}
@stop

@section('head')
<link rel="stylesheet" href="{{wkp_url('',['css','select2.css'])}}"/>
<link rel="stylesheet" href="{{wkp_url('',['css','select2.bootstrap.css'])}}" />
<link rel="stylesheet" href="{{wkp_url('',['css','pretty-checkboxes.css'])}}"/>
<link rel="stylesheet" href="{{wkp_url('',['plugins','datatables','dataTables.bootstrap.css'])}}">

<script type="text/javascript" src="{{wkp_url('',['js','select2.full.js'])}}"></script>
@stop


@section('content')
    @include('common.header')
    @include('common.menu')
    
<div id="main-page" class="content-wrapper api_page">
    <section class="content-header">
      <div class="row">
        <div class="col-sm-7 no-gutter">
          <h1>{{trans('commons.titles.myApiConnections')}}<small>{{trans('commons.api-Page.sub-headline')}}</small> </h1>
        </div>
        <div class="col-sm-5 text-right no-gutter"> <a class="submit-green" href="{{wkp_url('',['api-manager','create'])}}">{{trans('commons.api-Page.bt-create')}}</a> </div>
      </div>
    </section>

    <section class="content">
      <div class="row">
        <div class="col-xs-12 no-gutter">
          <div class="maincontent" id="api-index">
            <div class="box box-primary chart-box">
              <div class="box-header with-border">
                <h3 class="box-title">{{trans('commons.statistics')}}</h3>
                <div class="pull-right time-period">
                  <div class="dropdown">
                    <button class="btn dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"> LAST WEEK <i class="fa fa-angle-down"></i> </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                      <li><a href="#">{{trans('commons.stats.today')}}</a></li>
                      <li><a href="#">{{trans('commons.stats.last-week')}}</a></li>
                      <li><a href="#">{{trans('commons.stats.last-month')}}</a></li>
                      <li><a href="#">{{trans('commons.stats.last-year')}}</a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="box-body">
                <div class="chart">
                  <canvas height="250" width="789" id="areaChart" style="height: 250px; width: 789px;"></canvas>
                </div>
              </div>
              <div class="box-footer">
                <div class="col-xs-12">
                  <div class="col-xs-4 text-center">
                <div class="checkbox checkbox-success checkbox-inline">
                      <input id="inlineCheckbox1" value="option1" checked type="checkbox">
                      <label for="inlineCheckbox1">{{trans('commons.labels.api_impressions')}}</label>
                    </div>
                  </div>
                  <div class="col-xs-4 text-center">
                    <div class="checkbox checkbox-primary checkbox-inline">
                      <input id="inlineCheckbox2" value="option2" checked type="checkbox">
                      <label for="inlineCheckbox2">{{trans('commons.labels.api_clicks')}}</label>
                    </div>
                  </div>
                  <div class="col-xs-4 text-center">
                    <div class="checkbox checkbox-warning checkbox-inline">
                      <input id="inlineCheckbox3" value="option3" checked type="checkbox">
                      <label for="inlineCheckbox3">{{trans('commons.labels.api_cost')}}</label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="box connection-list">
            <div class="box-header">
              <h3 class="box-title">{{trans('commons.titles.Connections-List')}}</h3>
            </div>
              <div class="box-body">
                <table id="connection-table" class="table  connection-table change-connection-table">
                  <thead>
                    <tr>
                      <th>{{trans('commons.labels.image')}}</th>
                      <th>{{trans('commons.labels.name')}}</th>
                      <th>{{trans('commons.labels.id')}}</th>
                      <th>{{trans('commons.labels.status')}}</th>
                      <th class="text-center">{{trans('commons.actions.edit')}}</th>
                      <th>{{trans('commons.labels.credentials')}}</th>
                      <th class="text-center">{{trans('commons.actions.delete')}}</th>
                    </tr>
                  </thead>
                  <tbody class="change-connection-table-body">
                    @foreach($connections as $connection)
                    <tr id="connection_row_{{$connection->id}}">
                      <td class="conn-image"><img src="{{wkp_url('') .'/'. $connection->api->icon_url}}" /></td>
                      <td ><a href="{{wkp_url('',['api-manager','edit',$connection->id])}}" title="{{trans('commons.actions.edit')}} '{{$connection->name}}'" >{{$connection->name}}</a></td>
                      <td>{{$connection->id}}</td>
                      <td class="conn-status">
                        <span id="status_api{{$connection->id}}" class="label label-success">{{trans('commons.status.live')}}</span>
                        &nbsp;
                        {{--<a title="{{trans('commons.actions.check')}}" onclick="checkCatipoAPI('{{$connection->id}}')"><i class="fa fa-refresh"></i></a></td>--}}
                      <td class="text-center"><a href="{{wkp_url('',['api-manager','edit',$connection->id])}}" title="{{trans('commons.actions.edit')}}"><i class="fa fa-pencil"></i></a></td>
                      <td><dl>
                          <dt>{{$connection->api->uid_key}}:&nbsp;</dt>
                          <dd>{{$connection->api_uid}}</dd>
                          @if($connection->api->secret_key != '' && $connection->api->secret_key != null)
                          <dt>{{$connection->api->secret_key}}:&nbsp;</dt>
                          <dd>{{$connection->api_key}}</dd>
                          @endif
                          @if($connection->api->url_key != '' && $connection->api->url_key != null)
                          <dt>{{$connection->api->url_key}}:&nbsp;</dt>
                          <dd>{{$connection->api_url}}</dd>
                          @endif
                        </dl></td>
                      <td class="text-center"><a onclick="check_del()" href="{{wkp_url('',['api-manager','remove',$connection->id])}}" title="{{trans('commons.actions.remove')}}"><i class="fa fa-trash"></i></a></td>
                    </tr>
                    @endforeach
                  </tbody>
                </table>
              </div><!-- /.box-body -->

          </div>
          <!-- /.box -->

        </div>
      </div>
    </section>
</div>

@include('common.footer')
@stop


@section('footer_scripts')
        <!-- ChartJS 1.0.1 -->
    <script src="{{wkp_url('',['plugins','chartjs','Chart.min.js'])}}"></script>
    <script src="{{wkp_url('',['js','chart-custom-data.js'])}}"></script>
    <!-- DataTables -->
    <script src="{{wkp_url('',['plugins','datatables','jquery.dataTables.min.js'])}}"></script>
    <script src="{{wkp_url('',['plugins','datatables','dataTables.bootstrap.min.js'])}}"></script>

    <script type="application/javascript">

      function check_del() {
        confirm("Are you sure you want to remove this connection?");
      }

      var $selector = $("#api");
      $selector.select2({

        ajax: {
          url: '{{wkp_url('',['api-manager','getapis'])}}',
          dataType: 'json',
          delay: 200,
          data: function (params) {
            return {
              q: params.term
            };
          },
          processResults: function (data) {
            return {
              results: data.apis
            };
          },
          cache: true
        },

        escapeMarkup: function (markup) { return markup; },
        templateResult: formatEle,
        templateSelection: formatEleSelect
      }).on("change", function() {
        var data = $(this).select2('data');
        $('#uid_group label').html(''+data[0].uid_key);
        if(data[0].secret_key != null && data[0].secret_key != ''){
          $('#secret_group').show();
          $('#secret_group label').html(data[0].secret_key);
        }else{
          $('#secret_group').hide();
        }
        if(data[0].url_key != null && data[0].url_key != ''){
          $('#url_group').show();
          $('#url_group label').html(data[0].url_key);
        }else{
          $('#url_group').hide();
        }
      });

      function formatEle(data){
        var markup =  "";
        if(data.icon_url) {
          markup += "<div style='min-height:60px'><img style='float:left; margin-right:10px' src='{{wkp_url('')}}/" + data.icon_url + "' /><div>";
        }
        markup += "<b>"+data.name+"</b><br/>";
        if(data.description){
          markup += "<small>"+data.description+"</small>";
        }
        markup += "</div>";
        return markup;

      }

      function formatEleSelect (data) {
        console.log('formatting data selected: ' + data.name);

        return data.name;
      }

      function checkCatipoAPI(api_id) {
        var requestURL = '{{wkp_url('',['api-manager','fastping'])}}/'+api_id;
        $.getJSON(requestURL, function () {
          console.log("success asking to Catipo");
        }).done(function(data) {
          console.log("success asking to Catipo: done");
          if (data && data.status == 'ok') {
            console.log("done:  status OK");
            checkAPIWebPing(data.url,api_id);
          } else {
            console.log("done:  status fail");
            alert('The Catipo response wasnt succesful');
          }
        });
      }
      function checkAPIWebPing(url,api_id){
        console.log("checkAPIWebPing " + url);

        var jqxhr = $.getJSON(url , function () {
          console.log("success ping to " + url);
        }).done( function(data) {
          console.log("done method on " + url);
          if (data) {
            console.log('data exists');
            if( data.response){
              if(data.response.status == 'ok' || data.response.status == 'OK' || data.response.status == '1'){
                console.log('SUCCESS');
                apiConnectSuccess(api_id);
                return null;
              }
            }else{
              if(data.status == 'ok' || data.status == 'OK' || data.status == '1'){
                console.log('SUCCESS');
                apiConnectSuccess(api_id);
                return null;
              }
            }
          }
        });
      }

      function apiConnectSuccess(api_id){
        alert('success on ' + api_id + " ;)");
      }

      @if (count($errors) > 0)
          @foreach ($errors->all() as $error)
              $.notify({message: '{{$error}}'},{type: 'danger',animate: {enter: 'animated fadeInRight', exit: 'animated fadeOutRight'}});
          @endforeach
      @endif



     // On Ready
      $(function () {

        // DataTables

        $("#connection-table").DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": true,
          "ordering": true,
          "info": true,
          "autoWidth": false,
          "aaSorting": [],

          "aoColumnDefs": [
            { 'bSortable': false, 'aTargets': [ 0,1,2,3,4,5,6 ] }
          ],
          "sPaginationType": 'numbers',
          "bFilter": false,
          "bInfo": false,
          "bLengthChange": false,
        });

        /* ChartJS */
        // Get context with jQuery - using jQuery's .get() method.
        var areaChartCanvas = $("#areaChart").get(0).getContext("2d");

        // This will get the first returned node in the jQuery collection.
        var areaChart = new Chart(areaChartCanvas);

        var areaChartData = {
          labels: ["January", "February", "March", "April", "May", "June", "July"],
          datasets: [
            {
              label: "Electronics",
              fillColor: "rgba(60,205,226,0.25)",
              strokeColor: "rgba(60,205,226)",
              pointColor: "rgba(210, 214, 222, 1)",
              pointStrokeColor: "#c1c7d1",
              pointHighlightFill: "#fff",
              pointHighlightStroke: "rgba(220,220,220,1)",
              data: [65, 59, 80, 81, 56, 55, 40]
            },
            {
              label: "Digital Goods",
              fillColor: "rgba(60,205,226,0.75)",
              strokeColor: "rgba(60,205,226)",
              pointColor: "#3b8bba",
              pointStrokeColor: "rgba(60,141,188,1)",
              pointHighlightFill: "#fff",
              pointHighlightStroke: "rgba(60,141,188,1)",
              data: [28, 48, 40, 19, 86, 27, 90]
            }
          ]
        };

        var areaChartOptions = {
          //Boolean - If we should show the scale at all
          showScale: true,
          //Boolean - Whether grid lines are shown across the chart
          scaleShowGridLines: false,
          //String - Colour of the grid lines
          scaleGridLineColor: "rgba(0,0,0,.05)",
          //Number - Width of the grid lines
          scaleGridLineWidth: 1,
          //Boolean - Whether to show horizontal lines (except X axis)
          scaleShowHorizontalLines: true,
          //Boolean - Whether to show vertical lines (except Y axis)
          scaleShowVerticalLines: true,
          //Boolean - Whether the line is curved between points
          bezierCurve: true,
          //Number - Tension of the bezier curve between points
          bezierCurveTension: 0.3,
          //Boolean - Whether to show a dot for each point
          pointDot: false,
          //Number - Radius of each point dot in pixels
          pointDotRadius: 4,
          //Number - Pixel width of point dot stroke
          pointDotStrokeWidth: 1,
          //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
          pointHitDetectionRadius: 20,
          //Boolean - Whether to show a stroke for datasets
          datasetStroke: true,
          //Number - Pixel width of dataset stroke
          datasetStrokeWidth: 2,
          //Boolean - Whether to fill the dataset with a color
          datasetFill: true,
          //String - A legend template
          legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].lineColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>",
          //Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
          maintainAspectRatio: true,
          //Boolean - whether to make the chart responsive to window resizing
          responsive: true
        };

        //Create the line chart
        areaChart.Line(areaChartData, areaChartOptions);
      });
    </script>

@stop