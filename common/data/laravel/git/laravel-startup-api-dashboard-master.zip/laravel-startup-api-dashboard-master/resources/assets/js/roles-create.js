jQuery(document).ready(function($)
{
    $("#role-create-submit").click(function()
    {
        var name = $("#name").val();
        var displayName = $("#display_name").val();
        var description = $("#description").val();
        $.ajax({
            url: '/api/role/create',
            type: 'POST',
            data:
            {
                name: name,
                display_name: displayName,
                description: description
            },
            async: false
        })
            .done(function()
            {
                window.location = "/role/create";
            }
        )
    });
});