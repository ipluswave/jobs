[![Build Status](https://travis-ci.org/pietermartin/sqlg.svg?branch=master)](https://travis-ci.org/pietermartin/sqlg)

Sqlg
====

**Sqlg** is a implementation of [Tinkerpop3](https://github.com/apache/incubator-tinkerpop) on a [RDBMS](http://en.wikipedia.org/wiki/Relational_database_management_system).
Currently [HSQLDB](http://hsqldb.org/) and [Postgresql](http://www.postgresql.org/) are supported.


Documentation [here](http://umlg.org/sqlg.html).

