<?php
// Authentication routes...
Route::get('auth/login', ['middleware'=>'redirect.token','uses'=>'Auth\AuthController@getLogin']);
Route::post('auth/login', ['middleware'=>'token.save','uses'=>'Auth\AuthenticateController@authenticate']);
Route::get('auth/logout', ['middleware'=>'token.delete','uses'=>'Auth\AuthenticateController@logout']);

// Registration routes...
Route::get('auth/register', 'Auth\AuthController@getRegister');
Route::post('auth/register', 'Auth\AuthenticateController@postRegister');

Route::controllers([
    'password' => 'Auth\PasswordController',
]);