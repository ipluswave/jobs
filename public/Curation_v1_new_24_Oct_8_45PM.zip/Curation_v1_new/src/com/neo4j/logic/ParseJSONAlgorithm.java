package com.neo4j.logic;

public class ParseJSONAlgorithm {

}
