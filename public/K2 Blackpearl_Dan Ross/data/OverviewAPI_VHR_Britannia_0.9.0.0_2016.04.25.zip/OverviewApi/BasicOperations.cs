﻿using System;
using System.Collections.Generic;
using System.Threading;
using CustomerCommonApi;
using CustomerCommonApi.Model.Admin;
using CustomerCommonApi.Model.Report;
using CustomerCommonApi.Request.Admin;
using CustomerCommonApi.Request.Report;
using GatewayCommonApi;
using GatewayCommonApi.Model.Admin;
using GatewayCommonApi.Model.Domain;
using GatewayCommonApi.Request.Admin;
using GatewayCommonApi.Request.Domain;
using NUnit.Framework;

namespace OverviewApi
{
    public class BasicOperations
    {
        private const String USER_NAME = "dev_brit";
        private const String PASSWORD = "overview1q2w!Q@W";
        private const String CUSTOMER = "Britannia Developments";
      
        [Test]
        public void GetVehicleHistoryReport()
        {
            // Get the GUID for this user
            var overviewToken = TestFixture.GetOverviewToken(USER_NAME, PASSWORD);

            // Note that this points to the staging site. Change to production (overview.logikos.com) when ready.
            var gatewayService = GCAn.GetGatewayService(TestFixture.GatewayUrl);
            var customerRequest = new CustomerAdminRequest(gatewayService, overviewToken);
            var customer = customerRequest.GetByName(CUSTOMER);

            var customerService = CCAn.GetCustomerService(TestFixture.CustomerUrlBase, customer.Id.Value);

            /*This assumes the vehicle exists. It likely does not.*/
            var targetVehicle =  string.Format("VEHICLE - {0}", DateTime.Now.ToString());

            var assetRequest = new AssetAdminRequest(customerService, overviewToken);
            assetRequest.GetByName(targetVehicle);

            var targetModel = assetRequest.GetByName(targetVehicle);

            var vehicleHistoryRequest = new VehicleHistoryReportRequest(customerService, overviewToken);

            // The vehicle history report
            var report = vehicleHistoryRequest.Get(new VehicleHistoryQueryModel
            {
                AssetIDs = new List<int> {targetModel.Id.Value},
                SinceDate = DateTime.Now.AddDays(-7),
                BeforeDate = DateTime.Now
            });

            Assert.NotNull(report);
            Thread.Sleep(2000); // Wait 2 seconds so we get a new vehicle name
            
            /*As above, this assumes the vehicle exists. It likely does not.*/
            var anotherVehicleName = string.Format("VEHICLE - {0}", DateTime.Now.ToString());
            var anotherVehicle = assetRequest.GetByName(anotherVehicleName);
            
            /* Note: Do not populate the "UserName", "IncludeEntersAndExits", or "IncludeInsAndOuts". These are for Logikos use only. Their inclusion will result in an error being thrown in future releases.*/
            var multiReport = vehicleHistoryRequest.Get(new VehicleHistoryQueryModel
            {
                AssetIDs = new List<int> { targetModel.Id.Value,anotherVehicle.Id.Value },
                SinceDate = DateTime.Now.AddDays(-7),
                BeforeDate = DateTime.Now,
                MultiVehicle = true
            });

            Assert.NotNull(multiReport);
        }
    }
}