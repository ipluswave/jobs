<?php

namespace adsapi\Http\Controllers\ApiMan;

use adsapi\Api;
use adsapi\ApiConnection;
use adsapi\Category;
use adsapi\Method;
use adsapi\MethodCall;
use Illuminate\Http\Request;

use adsapi\Http\Requests;
use adsapi\Http\Requests\UpdateApiConnectionRequest;
use adsapi\Http\Requests\ConnectApiRequest;
use adsapi\Http\Controllers\Controller;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Response;

class ApiManagerController extends Controller
{

    public function __construct(){
        $this->middleware('auth');
    }

    public function getConnections(){
        $response = [];
        $response['responseType'] = 'connectionsByCategoryResponse';
        $connections = [];
        if( isset($_GET['category']) ){

            $response['status'] = 'ok';
            $category = Category::findOrFail($_GET['category']);
            $conns = ApiConnection::byCreator(Auth::user()->id);

            foreach($conns as $conn){
                if($conn->api->category == $category){
                    array_push($connections,$conn);
                }
            }
        }
        $response['connections'] = $connections;
        return $response;
    }
    /**
     * Display a listing of all the apis the system supports.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(){

        $connections = ApiConnection::latest('created_at')->byCreator(Auth::user()->id);
        $status = array("removed"=>false);
        return view('apimanager.api-index',compact("connections","status"));
    }

    public function getCreate(){
        $apisSelect = Api::getSelectList();
        $categories = Category::all()->lists('name','id');
        $status = array("created"=>false);
        return view('apimanager.api-create',compact("categories","apisSelect","status"));
    }

    public function postCreate(ConnectApiRequest $request ){

        $api = Api::find($request->api);
        //dd($api->categories);
        $newConnection = new ApiConnection();
        $newConnection->name = Auth::user()->first_name . '\'s '. $api->name . ' new connection';
        $newConnection->category_id = $request->api_type;
        $newConnection->api()->associate($api);
        $newConnection->creator()->associate(Auth::user());
        $newConnection->api_uid = $request->api_uid;
        $newConnection->api_key = $request->api_key;
        $newConnection->api_url = $request->api_url;
        $newConnection->save();

        return view('apimanager.status.created',compact("newConnection"));
    }

    public function getEdit($id){

        $connection = ApiConnection::findOrFail($id);
        $status = ['updated'=>false];
        if($connection->creator == Auth::user()){
            $labels = [];
            $labels["uid"] = $connection->api->uid_key;
            $labels["secret"] = $connection->api->secret_key;
            $labels["url"] = $connection->api->url_key;

            return view( 'apimanager.api-edit' , compact( 'connection' , 'labels','status' ) );
        }else{
            App::abort(405);
        }

    }

    public function postEdit(UpdateApiConnectionRequest $request, $id){
        $status = ["updated"=>false];
        $labels = [];
        $connection = ApiConnection::findOrFail($id);
        if($connection && $connection->creator == Auth::user()){

            $connection->creator()->associate(Auth::user());
            $connection->api_uid = $request->api_uid;
            $connection->api_key = $request->api_key;
            $connection->api_url = $request->api_url;
            $connection->save();

            $status = ["updated"=>true];

            $labels["uid"] = $connection->api->uid_key;
            $labels["secret"] = $connection->api->secret_key;
            $labels["url"] = $connection->api->url_key;
        }else{
            App::abort(405);
        }

        return view('apimanager.api-edit',compact('connection','status','labels'));
    }

    public function remove($id){
        $deletableConnection = ApiConnection::find($id);
        if (!is_null($deletableConnection)) {
            if ($deletableConnection->creator == Auth::user()){
                ApiConnection::destroy($id);
            } else {
                App::abort(405);
            }
        }else{
            App::abort(405);
        }
        $deletedConnection = $deletableConnection;

        return view('apimanager.status.removed', compact('deletedConnection'));
    }



    public function ping($id){
        $pingJson = [];
        $pingJson['response'] = 'ApiPingResponse' ;
        $connection = ApiConnection::findOrFail($id);
        switch($connection->api->auth_type){
            case 'web':
                $pingJson['type'] = 'web' ;
                $pingJson['url'] = $connection->getAPIPingURL();
                break;
            case 'base64':
                $pingMethod = Method::bySlug($connection->api->slug.'-authenticate');
                $pingJson['type'] = 'base64';
                $pingJson["apiresponse"] = $this->connect64($pingMethod,$connection);
                break;
        }
        $pingJson['status'] = 'ok' ;
        return $pingJson;
    }





    ////////////////////////////////////////////////////////////
    //////////////////// OLD METHODS FROM HERE /////////////////
    ////////////////////////////////////////////////////////////


    public function index_old()
    {
        $apisSelect = Api::getSelectList();
        $connections = ApiConnection::latest('created_at')->byCreator(Auth::user()->id);
        //dd($connections);
        $removed = null;
        $created = null;
        $categories = Category::all()->lists('name','id');

        return view('apiman.apilist', compact('apis','connections','apisSelect','removed','created','categories'));
    }

    /**
     * The get to create a new connection to an API.
     *
     * @return \Illuminate\Http\Response
     */
    public function connect(ConnectApiRequest $request)
    {
       // dd($request);
        $apiConnectionData = $request;
        $api = Api::find($request->api);
        //dd($api->categories);
        $newConnection = new ApiConnection();
        $newConnection->name = $request->name;
        $newConnection->api()->associate($api);
        $newConnection->creator()->associate(Auth::user());
        $newConnection->api_uid = $request->api_uid;
        $newConnection->api_key = $request->api_key;
        $newConnection->api_url = $request->api_url;
        $newConnection->save();

        $this->storeAPIAuthMethods($api,$newConnection);
        $this->storeAPISearchMethods($api,$newConnection);



        $removed = null;
        $created = 'The connection was created successfully';
        $apisSelect = Api::getSelectList();
        $connections = ApiConnection::latest('created_at')->byCreator(Auth::user()->id);

        return view('apiman.apilist', compact('api','apiConnectionData','apisSelect','connections','created','removed'));
    }

    private function storeAPIAuthMethods($api,$connection){
        $theMethod = Method::bySlug($api->slug . '-authenticate');
        $apiMethodCall = new MethodCall();
        $apiMethodCall->method()->associate($theMethod);
        $apiMethodCall->creator_id = Auth::user()->id;

        //TODO: possibly have to add uparams here based on method params

    }
    private function storeAPISearchMethods($api,$connection){
        $theMethod = Method::bySlug($api->slug . '-search');
        $apiMethodCall = new MethodCall();
        $apiMethodCall->method()->associate($theMethod);
        $apiMethodCall->creator_id = Auth::user()->id;

        //TODO: possibly have to add uparams here based on method params

    }



    /**
     * Show the form for creating a new api.
     * Only admin!!
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $apis = [];
        return view('apiman.apinew', compact('apis'));
    }


    /**
     * Display the specified api data.
     *
     * @param  string $name
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        //dd($api);
        $success = false;
        $connection = ApiConnection::findOrFail($id);
        $updated = false;
        return view('apiman.apiedit', compact('connection','updated'));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  string $name
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateApiConnectionRequest $request, $id)
    {

        $connection = ApiConnection::findOrFail($id);
        if($connection && $connection->creator == Auth::user()){
            $connection->name = $request->name;
            $connection->creator()->associate(Auth::user());
            $connection->api_key = $request->api_key;
            $connection->api_url = $request->api_url;
            $connection->save();
            $api = $connection->api;
            $updated = true;
        }else{

        }
        return view('apiman.apiedit', compact('api','connection','updated'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string $name
     * @return \Illuminate\Http\Response
     */





    private function connect64($pingMethod,$connection){
        $crl = curl_init();
        $base64encoded = base64_encode("[".$connection->api_uid."]:[".$connection->api_key."]");
        $header = array();
        $header[] = 'Authorization: Basic '. $base64encoded;
        $URL='https://www.supersonicads.com/partners/publisher/applications/';
        curl_setopt($crl, CURLOPT_URL, $URL);
        curl_setopt($crl, CURLOPT_HTTPHEADER, $header);
        $response = curl_exec($crl);
        curl_close($crl);


    }

    public function block($id){

        $connect = ApiConnection::findOrFail($id);

        $response = [];
        $response['responseType']='BlockageResponse';
        $response['id']=$id;

        if($connect->creator == Auth::user()){
            $connect->active = false;
            $connect->save();

            $response['status'] ='ok';
            $response['name'] = $connect->name;
            $response['message'] = 'The Connection has been blocked';
            $response['connectionStatus']='blocked';

        }else{

            $response['status'] ='fail';
            $response['name'] = $connect->name;
            $response['error'] = "You are not the owner of the connection '".$connect->name."', therefore, you can't block it";

        }

        return $response;
    }

    public function unblock($id){

        $connect = ApiConnection::findOrFail($id);

        $response = [];
        $response['responseType']='BlockageResponse';
        $response['id']=$id;

        if($connect->creator == Auth::user()){
            $connect->active = true;
            $connect->save();

            $response['status'] ='ok';
            $response['name'] = $connect->name;
            $response['message'] = 'The Connection has been unblocked';
            $response['connectionStatus']='unblocked';

        }else{

            $response['status'] ='fail';
            $response['name'] = $connect->name;

            $response['error'] = "You are not the owner of the connection '".$connect->name."', therefore, you can't unblock it";

        }
        return $response;

    }

    public function getApis(){
        $term = Input::get('q', '');
        $response = [];
        $response['status'] = 'OK';
        $response['httpStatus'] = '200';

        $apis = Api::where('name', 'LIKE', '%'.$term.'%')->get();
        $response['count'] = count($apis);
        $response['apis'] = $apis;

        return $response;


    }
    public function getApiLabel(){
        $apiID = Input::get('apiID');
       $api = Api::find($apiID);
       $list = array();
       $list[0] = $api;
       return Response::json(['result' =>'success', 'list' =>$list ]);
    }

    public function getApiList(){
        $categoryID  = Input::get('api_type');
        //$category  = Category::find($categoryID);

        //$apis = $category->apiCategories;
        $apis = Api::whereRaw('category_id= ?', array($categoryID))->get();
        $apiList = [];
        $list = '';
        $list .='<option value="">'.trans('commons.hints.api').'</option>';
        if(count($apis)>0){
            foreach ($apis as $key =>$api){
//                $api = Api::find($api->api_id);
                $list.= '<option value="'.$api->id.'">'.$api->name.'</option>';
            }
        }


        return Response::json(['result' =>'success', 'list' =>$list ]);
    }

   
}

