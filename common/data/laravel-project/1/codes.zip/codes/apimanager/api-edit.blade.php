@extends('layouts.index')

@section('title')
    {{trans('commons.titles.editConn')." '".$connection->name."'"}}
@stop

@section('head')

@stop
@section('sub_head')
    <link href="{{wkp_url('',['css','api.css'])}}" rel="stylesheet" />
@stop
@section('content')
    @include('common.header')
    @include('common.menu')

    <div id="main-page" class="content-wrapper api_edit">
        {!!Form::model($connection,array('url' => wkp_url('',['api-manager','edit']).'/'.$connection->id,'role'=>'form','method' => 'PATCH')) !!}
            <section class="content-header span6 content-centered">
                <div class="row">
                    <div class="row margin-bottom-30">
                        <div class="col-md-12">
                            <h1 class="api_header_text">{{trans('commons.titles.edit_api')}}<small>{{trans('commons.titles.edit_api_text')}}</small></h1>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-sm-offset-3 col-md-offset-3">
                        <div class="form-group">
                            {!! Form::label('id',trans('api.contents.id')) !!}
                            {!! Form::text('id',$connection->id, ['class' => 'form-control', 'disabled' =>"disabled"]) !!}
                        </div>
                        <div class="form-group">
                            {!! Form::label('api', trans('commons.labels.provider')) !!}
                            {!! Form::text('api',$connection->api->name, ['class' => 'form-control', 'disabled' =>"disabled"]) !!}
                        </div>
                        <div class="form-group {{$errors->has('api_uid') ? 'has-error' : ''}}">
                           {!! Form::label('api_uid', $labels['uid']) !!}
                           @if($errors->has('api_uid'))
                               <div class="error-feedback">
                                   {{$errors->first('api_uid')}}
                               </div>
                           @endif
                           {!! Form::text('api_uid',old('api_uid'), ['class' => 'form-control']) !!}
                        </div>
                        @if(isset($labels['secret']))
                            <div class="form-group {{$errors->has('api_key') ? 'has-error' : ''}}">
                                {!! Form::label('api_key', $labels['secret']) !!}
                                @if($errors->has('api_key'))
                                    <div class="error-feedback">
                                        {{$errors->first('api_key')}}
                                    </div>
                                @endif
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                    {!! Form::text('api_key',old('api_key'), ['class' => 'form-control']) !!}
                                </div>
                            </div>
                        @endif
                        @if(isset($labels['url']))
                            <div class="form-group margin-bottom-20 {{$errors->has('api_url') ? 'has-error' : ''}}">
                                {!! Form::label('api_url', $labels['url']) !!}
                                @if($errors->has('api_url'))
                                    <div class="error-feedback">
                                        {{$errors->first('api_url')}}
                                    </div>
                                @endif
                                <div class="input-group">
                                    <span class="input-group-addon">http://</span>
                                    {!! Form::text('api_url',old('api_url'), ['class' => 'form-control']) !!}
                                </div>
                            </div>
                        @endif
                    </div>
                    <div class="col-md-6 col-sm-6 col-sm-offset-3 col-md-offset-3 margin-bottom-30 margin-top-20">
                        <div class="row">
                            <div class="col-md-12" style="text-align: center">
                                {!! Form::submit(trans('commons.buttons.update'), ['class' => 'submit-green btn ']) !!}
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Main content -->

        {!!  Form::close() !!}
    </div>



    @include('common.footer')
@stop

@section('footer_scripts')
    <script type="text/javascript">

        @if ($status['updated'])
              $.notify({message: '{{trans('commons.notifications.apiUpdated',array('name'=>$connection->name))}}'},{type: 'success',animate: {enter: 'animated fadeInRight', exit: 'animated fadeOutRight'}});

        @endif


    </script>
    @stop