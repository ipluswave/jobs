@extends('layouts.index')

@section('title')
    API Management
@stop

@section('head')

@stop


@section('content')
    @include('common.header')
    @include('common.menu')

    <div id="main-page" class="content-wrapper api_connect">
        <section class="content-centered span6 content-header content">
            <div class="row">
                <div class="col-xs-12 no-gutter">
                    <div class="box">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <img src="/img/create_catalogue.jpg" style="width: 100%;">
                                </div>
                                <div class="col-md-12" style="text-align: center; margin-bottom: 50px">
                                    <p>Your connection '<span id="connection_name">{{$newConnection->name}}</span>' to <span id=api_name">{{$newConnection->api->name}}</span> was succesfully created. :)</p>
                                    <p>You will be redirected to the catalogues list in <span id="timeout_seconds">5</span> seconds, <a href="{{wkp_url('',['api-manager'])}}">or go now!</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        {{--<div class="container">--}}
            {{--<p>Your connection '<span id="connection_name">{{$newConnection->name}}</span>' to <span id=api_name">{{$newConnection->api->name}}</span> was succesfully created. :)</p>--}}
            {{--<p>You will be redirected to the connections list in <span id="timeout_seconds">5</span> seconds, <a href="{{wkp_url('',['api-manager'])}}">or go now!</a></p>--}}
        {{--</div>--}}
    </div>
    @include('common.footer')
@stop

@section('footer_scripts')
<script type="text/javascript">
    $( document ).ready(function() {
        window.setTimeout(function(){

            // Move to a new location or you can do something else
            window.location.href = "{{wkp_url('',['api-manager'])}}";

        }, 5000);
    });

</script>
@stop